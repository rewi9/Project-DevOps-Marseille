Please refer to https://github.com/kubernetes/community/blob/master/contributors/devel/sig-storage/flexvolume.md for documentation.
