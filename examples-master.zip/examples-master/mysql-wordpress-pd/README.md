# Example: WordPress and MySQL on Kubernetes

This directory contains the Kubernetes manifest files of the WordPress and
MySQL tutorial for Kubernetes.

Follow this tutorial at https://kubernetes.io/docs/tutorials/stateful-application/mysql-wordpress-persistent-volume/.
